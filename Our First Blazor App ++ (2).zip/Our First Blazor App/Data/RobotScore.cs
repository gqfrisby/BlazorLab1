﻿namespace Our_First_Blazor_App.Data
{
    public class RobotScore
    {
        public string AllianceNumber { get; set; }
        public int ScoreType1 { get; set; }
        public int ScoreType2 { get; set; }
        public int ScoreType3 { get; set; }
    }
}
